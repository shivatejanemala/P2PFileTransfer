package peerProcessPackage;

import java.net.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;
import java.util.*;

import org.apache.log4j.Logger;

public class PeerListener implements Runnable{

	private static int sPort = 8000;   //The server will be listening on this port number
	static Logger log = Logger.getLogger(DataMessage.class.getName());
   	private String listenMessage;    //message received from the client
   	private String sendMsg;    //uppercase message send to the client
	private ObjectInputStream in;	//stream read from the socket
	private OutputStream out;    //stream write to the socket
	private ServerSocket connection;
	private String clientPeer;
	private int currentPeerID;
	private boolean isNewConnection;
	private HashMap<String,Socket> connectedPeerMap;
	

	public PeerListener(int serverPort, int currentPeer) {
		this.sPort = serverPort;
		this.currentPeerID = currentPeer;
		connectedPeerMap = new HashMap<>();
	}
	
	public boolean isNewConnection() {
		return isNewConnection;
	}

	public void setNewConnection(boolean isNewConnection) {
		this.isNewConnection = isNewConnection;
	}

	public boolean sendHandShakeMsg() 
	{
		try 
		{
			HandShakeMessage hsMsg = new HandShakeMessage(DataMesssageConstants.HAND_SHAKE_HEADER,Integer.toString(currentPeerID));
			sendMessage(hsMsg.createSendHandshakeMsg());
			log.info("HandShake Request sent from Peer-"+currentPeerID + "to "+ clientPeer);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendHandshake to : " + e.getMessage());
		}
		return true;
	}
	
	public boolean receiveHandShakeMsg() 
	{
		try 
		{
			byte[] receiveHandShakeMsg = new byte[DataMesssageConstants.HAND_SHAKE_MESSAGE_LENGTH];
			int x = in.read(receiveHandShakeMsg);
			if(x>0) {
				HandShakeMessage hsMsg = HandShakeMessage.createReceiveHandshakeMsg(receiveHandShakeMsg);
				clientPeer = hsMsg.getPeerId().toString();
				log.info("Received HandShake Message from -"+clientPeer);}
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendHandshake to : " + e.getMessage());
		}
		return true;
	}

	public boolean sendDataMsg(String type,String payLoad) 
	{
		try 
		{
			DataMessage dataMsg = new DataMessage(type,payLoad);
			sendMessage(dataMsg.createSendDataMsg());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendData Message to : " + e.getMessage());
		}
		return true;
	}
	
	public boolean receiveDataMsg() 
	{
		try 
		{
			byte[] receiveHandShakeMsg = null;
			int x = in.read(receiveHandShakeMsg);
			if(x != DataMesssageConstants.HAND_SHAKE_MESSAGE_LENGTH) {
				throw new Exception("Error while receiving the incoming handshake message");
			}
			DataMessage dataMsg = DataMessage.createReceiveDataMsg(receiveHandShakeMsg);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendHandshake to : " + e.getMessage());
		}
		return true;
	}
	
	public boolean sendChokeDataMsg() 
	{
		try 
		{
			DataMessage dataMsg = new DataMessage(Integer.toString(DataMesssageConstants.CHOKE_MESSAGE_TYPE),null);
			sendMessage(dataMsg.createSendDataMsg());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendData Message to : " + e.getMessage());
		}
		return true;
	}
	
	public boolean sendUnChokeDataMsg() 
	{
		try 
		{
			DataMessage dataMsg = new DataMessage(Integer.toString(DataMesssageConstants.UNCHOKE_MESSAGE_TYPE),null);
			sendMessage(dataMsg.createSendDataMsg());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendData Message to : " + e.getMessage());
		}
		return true;
	}
	public boolean sendInterestedDataMsg() 
	{
		try 
		{
			DataMessage dataMsg = new DataMessage(Integer.toString(DataMesssageConstants.INTERESTED_MESSAGE_TYPE),null);
			sendMessage(dataMsg.createSendDataMsg());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendData Message to : " + e.getMessage());
		}
		return true;
	}
	
	public boolean sendIUnnterestedDataMsg() 
	{
		try 
		{
			DataMessage dataMsg = new DataMessage(Integer.toString(DataMesssageConstants.UNINTERESTED_MESSAGE_TYPE),null);
			sendMessage(dataMsg.createSendDataMsg());
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(new Date().toInstant()+ "Error while sending the  SendData Message to : " + e.getMessage());
		}
		return true;
	}
	
	
	public void run() {
	 		try{
	 			 connection = new ServerSocket(sPort);
				//initialize Input and Output streams
	 			Socket remotePeer = null;
				try{
					while(true)
					{
						remotePeer = connection.accept();
						out = remotePeer.getOutputStream();
						out.flush();
						in = new ObjectInputStream(remotePeer.getInputStream());
						break;
					}
				}
				catch(Exception e) {
					log.error("Exception occured while communicating For "+currentPeerID+"with peer-"+clientPeer + ":- "+ e.getMessage());
				}
				
				if(isNewConnection) {
					boolean isValidHandshakeSent = sendHandShakeMsg();
					if(isValidHandshakeSent) {
						while(true) {
								boolean isValidHandShakeRec = receiveHandShakeMsg();
								if(isValidHandShakeRec) {
									log.info("HandShakes Established from -"+ currentPeerID + " to remote Peer-"+ clientPeer);
									connectedPeerMap.put(clientPeer,remotePeer);
								}
						}
					}
				}
				else {
					
				}
	 		}
			catch(IOException ioException){
				log.info("Disconnect with Client " + clientPeer);
			}
			finally{
				//Close connections
				try{
					in.close();
					out.close();
					connection.close();
				}
				catch(IOException ioException){
					log.info("Disconnect with Client " + clientPeer);
				}
			}
		}
	//send a message to the output stream
	public void sendMessage(byte[] msg)
	{
		try {
			out.write(msg);
			out.flush();
			log.info("Send message: " + msg + " to Client " + clientPeer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

    }


